export default {
  "bootstrapScriptContent": "import(\"/analyze/assets/index-BtRpz2tR.js\")",
  "clientReferenceDeps": {
    "ec9d1e977e38": {
      "js": [
        "/analyze/assets/road-analyzer-BUVtkR3q.js",
        "/analyze/assets/rolldown-runtime-S-ySWqyJ.js",
        "/analyze/assets/framework-CXnKph_e.js",
        "/analyze/assets/index-BtRpz2tR.js"
      ],
      "css": []
    },
    "593f344dc510": {
      "js": [
        "/analyze/assets/index-BtRpz2tR.js",
        "/analyze/assets/rolldown-runtime-S-ySWqyJ.js",
        "/analyze/assets/framework-CXnKph_e.js"
      ],
      "css": []
    },
    "15c18cfaeeff": {
      "js": [
        "/analyze/assets/layout-segment-context-DCEs-7U6.js",
        "/analyze/assets/rolldown-runtime-S-ySWqyJ.js",
        "/analyze/assets/index-BtRpz2tR.js",
        "/analyze/assets/framework-CXnKph_e.js"
      ],
      "css": []
    },
    "60f387d9e0f4": {
      "js": [
        "/analyze/assets/script-DUGEPyB5.js",
        "/analyze/assets/rolldown-runtime-S-ySWqyJ.js",
        "/analyze/assets/framework-CXnKph_e.js",
        "/analyze/assets/index-BtRpz2tR.js"
      ],
      "css": []
    },
    "8c0f216c4604": {
      "js": [
        "/analyze/assets/index-BtRpz2tR.js",
        "/analyze/assets/rolldown-runtime-S-ySWqyJ.js",
        "/analyze/assets/framework-CXnKph_e.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/analyze/assets/index-DTUcx4HY.css"
      ]
    }
  }
}