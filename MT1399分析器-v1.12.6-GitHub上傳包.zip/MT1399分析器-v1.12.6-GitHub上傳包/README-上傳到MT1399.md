# MT1399 分析器 v1.12.6｜GitHub 上傳包

此 ZIP 來自正式 `main` 分支 commit：

`863961a26cd87f2cf50a976ca9095cddf6e4c75f`

## 版本範圍

- 正式 MT1399 百家樂牌路分析器 v1.12.6
- 公開介紹與同 IP 20 局試用
- 網址基底：`/analyze/`
- 不包含後來的 MT 即時讀牌實驗室
- 分析器核心程式未修改

## 上傳前注意

1. 解壓 ZIP。
2. 將資料夾內的檔案上傳到目前連接 Cloudflare 的 GitHub Repository／部署分支。
3. 保留 GitHub 既有的 `wrangler.jsonc`，尤其是真實 D1 `database_id`、Worker 名稱及正式 Route。
4. 不要上傳 `.env`、Secrets、`node_modules`、`dist`、`.wrangler`。
5. 等 Cloudflare 自動建置完成後，開啟 `https://mt1399.com/analyze/` 驗收。

本包刻意不包含環境專用的 `wrangler.jsonc`，避免覆蓋正式站既有的 D1 設定。

## 建置與驗證

```bash
npm ci
npm run test:unit
npm run lint
npm run build:app
```

打包前驗證結果：

- 單元測試：10 passed、0 failed、6 skipped；IP 試用測試 7 passed、0 failed
- ESLint：0 errors、5 個既有 warnings
- 正式建置：成功
- 建置路由：首頁、`/api/learning`、`/api/trial/status`、`/api/trial/use`

## 部署後確認

- 頁面顯示 `v1.12.6`
- Logo、範例圖片與靜態資源正常
- 成功分析後，試用次數由 20 變成 19
- 重新整理後仍維持 19
- 低解析度／辨識失敗不扣次
- 網址為 `https://mt1399.com/analyze/`
